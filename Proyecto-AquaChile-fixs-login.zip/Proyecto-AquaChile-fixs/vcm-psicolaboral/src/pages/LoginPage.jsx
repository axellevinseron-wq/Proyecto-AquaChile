import { useState } from "react";
import Icon from "../components/Icon";

const CLAVE_USUARIO = "vcm-usuario-recordado";

function leerUsuarioRecordado() {
  try {
    return localStorage.getItem(CLAVE_USUARIO) ?? "";
  } catch {
    return "";
  }
}

function guardarUsuarioRecordado(valor) {
  try {
    if (valor) {
      localStorage.setItem(CLAVE_USUARIO, valor);
    } else {
      localStorage.removeItem(CLAVE_USUARIO);
    }
  } catch {
    // Sin almacenamiento disponible: simplemente no se recuerda el usuario.
  }
}

function LoginPage({ onLogin }) {
  const [usuario, setUsuario] = useState(leerUsuarioRecordado);
  const [clave, setClave] = useState("");
  const [recordar, setRecordar] = useState(() => leerUsuarioRecordado() !== "");
  const [mensaje, setMensaje] = useState("");

  function enviar(evento) {
    evento.preventDefault();
    const nombre = usuario.trim();

    if (!nombre || !clave) {
      setMensaje("Ingresa tu usuario y contraseña.");
      return;
    }

    // Prototipo: aún no hay validación real de credenciales.
    // Aquí se llamará al backend cuando esté integrado.
    guardarUsuarioRecordado(recordar ? nombre : "");
    onLogin(nombre);
  }

  return (
    <main className="login-page">
      <form className="login-card" onSubmit={enviar} noValidate>
        <span className="login-avatar" aria-hidden="true">
          <Icon nombre="user" size={64} />
        </span>

        <h1 className="login-titulo">VcM Psicolaboral</h1>

        <div className="login-campo">
          <span className="login-campo__icono" aria-hidden="true">
            <Icon nombre="user" size={16} />
          </span>
          <label className="visually-hidden" htmlFor="login-usuario">Usuario</label>
          <input
            id="login-usuario"
            type="text"
            autoComplete="username"
            placeholder="Usuario"
            value={usuario}
            onChange={(evento) => {
              setUsuario(evento.target.value);
              setMensaje("");
            }}
          />
        </div>

        <div className="login-campo">
          <span className="login-campo__icono" aria-hidden="true">
            <Icon nombre="lock" size={16} />
          </span>
          <label className="visually-hidden" htmlFor="login-clave">Contraseña</label>
          <input
            id="login-clave"
            type="password"
            autoComplete="current-password"
            placeholder="Contraseña"
            value={clave}
            onChange={(evento) => {
              setClave(evento.target.value);
              setMensaje("");
            }}
          />
        </div>

        {mensaje && (
          <p className="login-mensaje" role="alert">
            {mensaje}
          </p>
        )}

        <div className="login-opciones">
          <label className="login-recordar">
            <input
              type="checkbox"
              checked={recordar}
              onChange={(evento) => setRecordar(evento.target.checked)}
            />
            Recordarme
          </label>
          <button
            type="button"
            className="login-olvido"
            onClick={() =>
              setMensaje("La recuperación de contraseña estará disponible al integrar el backend.")
            }
          >
            ¿Olvidaste tu contraseña?
          </button>
        </div>

        <button type="submit" className="login-boton">
          INGRESAR
        </button>
      </form>
    </main>
  );
}

export default LoginPage;
