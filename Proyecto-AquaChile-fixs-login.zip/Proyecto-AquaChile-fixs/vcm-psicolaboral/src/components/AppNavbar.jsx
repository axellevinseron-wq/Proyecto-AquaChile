import Icon from "./Icon";

function AppNavbar({ sidebarAbierto, onToggleSidebar }) {
  return (
    <header className="main-header">
      <a className="main-header__brand" href="#inicio">
        VcM Psicolaboral
      </a>

      <nav className="main-header__nav" aria-label="Barra superior">
        {/* Botón hamburguesa a la derecha: abre y cierra el menú lateral derecho */}
        <button
          type="button"
          className="topbar-item topbar-toggle"
          onClick={onToggleSidebar}
          aria-label="Abrir o cerrar menú lateral"
          aria-expanded={sidebarAbierto}
          aria-controls="menu-lateral"
        >
          <Icon nombre="menu" size={22} />
        </button>
      </nav>
    </header>
  );
}

export default AppNavbar;
