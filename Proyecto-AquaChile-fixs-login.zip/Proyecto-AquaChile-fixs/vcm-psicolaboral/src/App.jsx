import { useState } from "react";
import AppNavbar from "./components/AppNavbar";
import Sidebar from "./components/Sidebar";
import DashboardPage from "./pages/DashboardPage";
import LoginPage from "./pages/LoginPage";

const ES_ESCRITORIO = "(min-width: 768px)";

function App() {
  // Sesión simulada en memoria; se reemplazará al integrar el backend.
  const [usuario, setUsuario] = useState(null);
  // En escritorio el menú lateral parte abierto; en móvil, cerrado.
  const [sidebarAbierto, setSidebarAbierto] = useState(
    () => window.matchMedia(ES_ESCRITORIO).matches,
  );

  function cerrarEnMovil() {
    if (!window.matchMedia(ES_ESCRITORIO).matches) {
      setSidebarAbierto(false);
    }
  }

  if (!usuario) {
    return <LoginPage onLogin={setUsuario} />;
  }

  return (
    <div className={`app-shell ${sidebarAbierto ? "sidebar-abierto" : "sidebar-cerrado"}`}>
      <AppNavbar
        sidebarAbierto={sidebarAbierto}
        onToggleSidebar={() => setSidebarAbierto((abierto) => !abierto)}
      />
      <Sidebar
        usuario={usuario}
        onNavegar={cerrarEnMovil}
        onCerrarSesion={() => setUsuario(null)}
      />
      <div className="sidebar-backdrop" onClick={cerrarEnMovil} aria-hidden="true" />

      <div className="content-wrapper">
        <DashboardPage />
      </div>

      <footer className="main-footer">
        Copyright © 2026 todos los derechos reservados.
      </footer>
    </div>
  );
}

export default App;
